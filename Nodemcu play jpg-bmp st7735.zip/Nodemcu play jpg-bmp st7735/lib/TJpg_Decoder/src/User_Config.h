#if defined (ESP32) || defined (ESP8266) || (ARDUINO_ARCH_RP2040)  || defined (ARDUINO_ARCH_MBED)
  #define TJPGD_LOAD_FFS
#endif

#define TJPGD_LOAD_SD_LIBRARY
